package Lex;

class TraditionalComment extends Comment {
  TraditionalComment() { }
}
