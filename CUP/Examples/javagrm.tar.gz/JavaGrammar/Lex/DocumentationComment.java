package Lex;

class DocumentationComment extends Comment {
  DocumentationComment() { }
}
  
