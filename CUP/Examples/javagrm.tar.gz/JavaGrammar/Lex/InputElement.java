package Lex;

abstract class InputElement {}
