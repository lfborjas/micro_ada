package Lex;

abstract class Literal extends Token { }
