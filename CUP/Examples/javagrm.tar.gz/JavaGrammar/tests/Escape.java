class Escape {
    String s = "\477"; // this literal is valid, but..
//  char c = '\477';   // this literal is invalid.
}
